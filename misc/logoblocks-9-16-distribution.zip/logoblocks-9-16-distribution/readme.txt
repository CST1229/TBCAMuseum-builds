Welcome to LogoBlocks 9/15/2001.

To install, double-click the j2re installer. This will install a Java 
runtime environment on your computer if it is not there already. (If you
have Java 1.2.x or an older version of Java 1.3.x on your computer, you
should uninstall it first. If you have Java 1.1.x on your computer, you
can leave it alone, if you wish). 

Once Java is installed, double-click on the LogoBlocks.bat file to launch
LogoBlocks.

If you have any questions, email logoblocks@media.mit.edu.

